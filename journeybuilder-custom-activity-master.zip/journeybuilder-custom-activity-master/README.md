# Custom Activity

### Installation
First, install all dependencies: `npm i`

Add all environment variables in `.env` file

Then, run in development mode: `npm run dev`
